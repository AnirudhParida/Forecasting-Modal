# Netraa — Training Dataset Export
Generated: 2026-08-24 18:51 IST

## Dataset Overview
- **Source**: Dynatrace (https://nlq64817.live.dynatrace.com)
- **Grid**: Coarse (1-day resolution)
- **Date range**: 2025-07-02 → 2026-08-24
- **Total days**: 419
- **Total metrics**: 72 (columns)
- **Overall coverage**: 56.8%

## File Guide

| File | Description |
|------|-------------|
| `00_summary.csv` | One row per metric: resource group, role (target/intermediate), unit, coverage %, min/max/mean/median/std |
| `all_metrics.csv` | Full dataset — 419 rows × 72 columns. Use this for custom analysis. |
| `targets_only.csv` | Only the **30 metrics the model forecasts** (CPU, Memory, Disk, JVM Heap) |
| `by_resource/cpu.csv` | CPU metrics only (2 metrics) |
| `by_resource/memory.csv` | Memory metrics (13 metrics) |
| `by_resource/disk.csv` | Disk metrics — IOPS, throughput, latency, busy time for 5 disks (34 metrics) |
| `by_resource/jvm.csv` | JVM metrics — Heap, GC, threads, CPU (12 metrics) |
| `by_resource/network.csv` | Network Rx/Tx bytes and packets (8 metrics) |
| `by_resource/service.csv` | Service call counts and DB access (3 metrics) |
| `daily_coverage.csv` | For each day: how many metrics had data, plus CPU and Memory values |

## Column Name Convention
Columns use friendly names: `{MetricType}_{DiskLabel}` or `{MetricType}_{JVMLabel}`

Disk labels: Disk-A through Disk-E (mapped from entity IDs)
JVM labels: JVM-1, JVM-2, JVM-3 (different JVM process groups)

## Roles
- **target**: Metrics the model directly forecasts (30 metrics)
- **intermediate**: Supporting metrics used as features/context (40 metrics)
- **driver**: High-level driver metrics (2 metrics)

## NaN Values
NaN means no data was available from Dynatrace for that day.
Some disk metrics have ~41% coverage (they are on standby disks).
Core metrics (CPU, Memory, Disk-B, Disk-E) have >98% coverage.
